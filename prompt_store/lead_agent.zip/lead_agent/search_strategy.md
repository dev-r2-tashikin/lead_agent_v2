
### **【SOP-A1】全球IVD潜在客户线索开发标准作业程序**

**版本：** 7.0 (自主循环与学习版)
**更新日期：** 2024-XX-XX (今日)
**版本说明：**
*   **核心理念：** 这是一份为“人类操作员与智能工具”协同工作而设计的SOP。它定义了工作流程、工具使用规范和判断标准。


### **第一部分：核心原则与准备**

1.  **目标驱动：** 我们的最终产出是经过**第四部分：标准评估模块**评估和打分的高质量线索。
2.  **人机协作：** 人类负责战略决策（如判断信息源的价值、决定下一步的探索方向），工具负责执行繁琐的信息获取工作。
3.  **证据链：** 每一条评估结论，都必须能追溯到`fetch`工具返回的原始信息。
4. **准备环节** 使用read_file_Content 工具 读取之前的执行记录和总结知识，对其深度理解, 包括`./output/result.md`,`./output/learning_log.md`,`./output/new_treasure_find.md`, `./output/action_log.md`。

请注意，搜索客户是永无止境的，记录中可能提到了已完成任务或者客户是足够的，但是这些都是错误的理解
---

### **第二部分：三步工作流**

#### **步骤一：种子客户深度侦察 (Step 1: Seed Customer Deep Dive)**

**目标：** 彻底研究一个`[种子客户]`，完成自身评估，并收集用于下一步扩张的情报。

1.  **发起搜索：**
    *   **操作人：** 决策使用哪个关键词。
    *   **调用工具：** `search_tools(query="[种子客户名称]", region="[目标区域]")`
    *   **产出：** 返回一个包含25个链接和摘要的搜索结果列表。

2.  **情报分析与筛选（人机协作）：**
    *   **操作人/LLM：** 审查返回的搜索结果列表。
    *   **任务：**
        a. **识别官网：** 在列表中找到并标记出`[种子客户]`的官方网站URL。
        b. **识别“藏宝图”线索：** 寻找那些可能指向“经销商名单”或“官方授权文件”的链接。特别关注那些URL中包含**其他公司名**、**政府机构缩写**或关键词如`distributors`, `partners`的链接。
        c. **识别风险：** 标记出那些可能引起混淆的链接（如错误的业务、错误的地区）。

3.  **深度信息提取与评估：**
    *   **操作人：** 基于上面的分析，选择最重要的URL（首先是官网）进行深度提取。
    *   **调用工具：** `fetch(url="[选定的URL]")`
    *   **产出：** `fetch`工具返回该页面的核心内容。
    *   **操作人/LLM：**
        a. 阅读`fetch`的产出。
        b. **调用** `第四部分：标准评估模块`，对`[种子客户]`进行打分和分级，并将生成的JSON评估结果**暂存**到你的内部“已验证线索列表”中。
        c. 从`fetch`的产出中，找到并记录所有**上游供应商**的名称和**关联的官方机构**名称，作为下一步的“弹药”。

#### **步骤二：策略性扩张搜索 (Step 2: Strategic Expansion Search)**

**目标：** 利用在步骤一收集到的**情报**，进行高效的“藏宝图”搜索。

1.  **决策扩张方向（人机协作）：**
    *   **操作人/LLM：** 查看在步骤一收集到的“弹药”（供应商列表、机构列表）。
    *   **任务：** 基于这些情报，生成一个按逻辑优先级排序的、新的搜索查询列表。
        *   *示例决策：* “我们发现了供应商‘Sanluc’，最高优先级的搜索应该是找到它的经销商页面。” -> 生成查询 `"Sanluc distributors"`

2.  **执行扩张搜索：**
    *   **操作人：** 遍历上一步生成的查询列表。
    *   **调用工具：** `search_tools(query="[新生成的查询]", region="...")`
    *   **产出：** 针对每个查询返回一个新的搜索结果列表。

3.  **挖掘“藏宝图”并记录：**
    *   **操作人/LLM：** 审查这些新的搜索结果列表，找到最有可能包含公司名单的“藏宝图URL”。
    *   **调用工具：** `fetch(url="[藏宝图URL]")`
    *   **产出：** `fetch`工具返回该名单页面的核心内容。
    *   **操作人/LLM：** 从`fetch`的产出中，提取出所有公司名称，形成`[新线索候选名单]`。同时，将这个有价值的“藏宝图URL”及其重要性说明（例如：“这是供应商Sanluc的官方经销商列表”）**暂存**到你的内部“藏宝图记录”中。
-
#### **步骤三：新线索批量验证与循环决策 (Step 3: New Lead Bulk Vetting & Loop Decision)**

**目标：** 对`[新线索候选名单]`上的所有公司进行标准化验证，并决定是否继续自主循环。

1.  **批量处理与暂存：**
    *   **操作人/LLM：** 遍历`[新线索候选名单]`。
    *   **循环体内的任务：** 对于每一个`[新公司名称]`：
        a. **调用** `search_tools` 进行快速搜索。
        b. **操作人** 快速判断其业务是否相关。
        c. 如果相关，**调用** `fetch` 获取其官网内容。
        d. **调用** `第四部分：标准评估模块`，完成对这个新公司的评估，并将生成的完整JSON评估结果**暂存**到你的内部“已验证线索列表”中。

2.  **迭代与循环决策：**
    *   **操作人/LLM：** 审查本轮所有已评估的新线索。在进入`第五部分`之前，你**必须**做出循环决策。
    *   **任务：**
        a. **检查循环条件：** 检查是否已达到用户在初始指令中指定的循环次数。
        b. **选择新种子：** 如果需要继续循环，**必须**从本轮发现的线索中，选择一个得分最高（例如，`total_score` > 90）且尚未被用作种子的公司，作为**下一轮循环的种子客户**。
        c. **启动新循环：** 如果找到了合适的新种子并且循环条件未满足，立即以这个新种子客户为目标，返回并开始执行`步骤一`。**不要停止，除非已满足循环次数要求或找不到合适的新种子。**
    *   **任务结束标志：** 只有当所有指定的循环次数完成后，你才能停止循环，并进入`第五部分`执行最终的总结与持久化。

---

### **第四部分：标准评估模块 (Standard Evaluation Module)**

**请遵循客户审判协议，分析列出寻找证据的计划、并执行，最终完成客户的审判。如果客户满足要求，请按照以下要求进行输出,使用`ininsert_text_at_linesert`工具更新到`./output/result.md`**


1.  **最终输出格式（结构化数据）：**
    *   **Company Name:** (公司名)
    *   **Website:** (官网URL)
    *   **phone:** (电话)
    *   **email:** (邮箱)
    *   **person:** (联系人姓名)
    *   **person_email:** (联系人邮箱)
    *   **Lead Class:** (KA / B / C)
    *   **describe:** (你挖掘到的该公司的描述)
    *   **Quality Score:**
        *   `sales_capability_score`: (0-50分)
        *   `product_experience_score`: (0-30分)
        *   `influence_score`: (0-20分)
        *   `total_score`: (三项总和)

---

### **第五部分：任务总结与持久化 (Task Summary & Persistence)**

**这是一个在完成所有指定循环后，必须执行的最终收尾步骤。**

1.  **总结你在该轮循环的动作**
    *   以markdown格式总结你在该轮循环的动作，以供之后的你进行查阅，从而完成新循环的任务，并使用工具更新 `./output/action_log.md`。

2.  **聚合“藏宝图”信息：**
    *   将你新发现的且你认为有价值的，但你没有深入探测的url一次性的保存下来。需要包括URL 以及 相应的注释, 保存在`./output/new_treasure_find.md`.

3.  **总结学习并持久化：**
    *   **执行自我复盘：** 根据`update_strategy.md`中的指导原则，回顾本轮所有循环中的成功与失败经验。
    *   **格式化学习成果：** 将你的复盘结论，整理成一个清晰的Markdown格式文本。
    *   **调用工具，将你的这个学习日志融合到 `./output/learning_log.md` 文件中。



**示例 `learning_log.md` 内容:**

```markdown
# Learning Log for Romania (ro) - Cycle 1 & 2

## Query Efficiency Evaluation

*   **High-Yield Query:** The query `"IVD distributors Romania"` was extremely effective. It directly led to the discovery of multiple high-quality KA-level leads like `K-MARA Healthcare` and `Mediclim`. This generic but domain-specific query template should be prioritized in future searches for new regions.
*   **Lesson:** Start with broad, industry-specific queries before narrowing down to supplier-specific ones.

## Source Yield Evaluation

*   **High-Yield Source:** `https://www.immundiagnostik.com/en/company/distributors` is a valuable "Treasure Map", confirming our seed customer and providing a global list.
*   **Challenge Identified:** The source `https://mes-global.com/distributors/` uses dynamic content loading, which `fetch` cannot fully process.
*   **New Rule:** When a distributor page is identified as dynamic, do not waste time trying to fetch it. Instead, immediately pivot to broader search queries or look for an alternative "Contact" or "Partners" page on the same domain.

## New Intelligence Keywords

*   Identified "uz veterinar" (veterinary use) as a strong local keyword for the veterinary diagnostics sector in Romania. This should be added to the keyword library for future veterinary-focused searches in this region.
```